
public class Designer extends Funcionario1{
	public double getBonificacao(){
		System.out.println("Chamando o metodo de bonificacao do DESIGNER");
		return 200;
	}
}
