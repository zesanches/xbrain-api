
//public class TesteFuncionario {
//	public static void main(String[] args) {
//		Funcionario1 nico = new Funcionario1();
//		
//		nico.setNome("Nico");
//		nico.setCpf("222.222.222-22");
//		nico.setSalario(2500.00);
//		
//		System.out.println(nico.getNome());
//		System.out.println(nico.getCpf());
//		System.out.println(nico.getSalario());
//		System.out.println(nico.getBonificacao());
//	}
//}
