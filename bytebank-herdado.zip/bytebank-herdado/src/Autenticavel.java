// isso � uma interface, ela n�o tem nada concreto, somente abstrato, somente as 
// assinaturas dos m�todos
public abstract interface Autenticavel {
	
	public abstract void setSenha(int senha);
	
	public abstract boolean autentica(int senha);
}
// Como entender:
// Contrato Autenticavel
	//quem assina esse contrato precisa:
		//metodo setSenha
		//metodo autentica