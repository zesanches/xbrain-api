// Gerente herda da class Funcionario
public class EditorVideo extends Funcionario1 {
		
	public double getBonificacao() {
		System.out.println("Chamando m�todo de bonificacao do EDITOR DE VIDEO");
		return 150; 
		//usando super no getBonificacao() pq vou usar a conta que est� na superClass (ou seja, podemos aproveitar os m�todos das classe m�e tamb�m)
		//mesma coisa para o getSalario()
		//indica que vem da superClass, ou da Classe m�e
		//em casos que se usa um atributo de uma classe m�e, melhor usar o super do que o this
	}	
}
	