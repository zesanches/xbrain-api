package br.com.alura.jdbc;
import java.sql.Connection;
import java.sql.SQLException;

public class TestaConexao {
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		
		ConnectionFactory connectionFactory = new ConnectionFactory();
		Connection connection = connectionFactory.recuperarConexao();
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		System.out.println("Fechando conex�o!");
		
		connection.close();		
	}
}
