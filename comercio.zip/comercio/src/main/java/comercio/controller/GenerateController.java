package comercio.controller;

import java.sql.Array;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class GenerateController {
	
	@RequestMapping("/generate")
	public List<Generate>lista() {
		Generate generate = new Generate("Vendedor1", "Venda", new Produtos("Venda1", "Produto1"));
		
		return Array.asList(generate, generate, generate);
	}
}
