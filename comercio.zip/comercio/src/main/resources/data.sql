INSERT INTO VENDEDOR(idVendedor, nomeVendedor) VALUES('1', 'Vendedor1');
INSERT INTO VENDEDOR(idVendedor, nomeVendedor) VALUES('2', 'Vendedor2');
INSERT INTO VENDEDOR(idVendedor, nomeVendedor) VALUES('3', 'Vendedor3');


INSERT INTO PRODUTO(id, valor) VALUES('10', '23,50');
INSERT INTO PRODUTO(id, valor) VALUES('20', '40,00');
INSERT INTO PRODUTO(id, valor) VALUES ('40', '100,00');
INSERT INTO PRODUTO(id, valor) VALUES ('50', '130,00');
INSERT INTO PRODUTO(id, valor) VALUES ('60', '90,00');
INSERT INTO PRODUTO(id, valor) VALUES ('70', '80,00');
INSERT INTO PRODUTO(id, valor) VALUES ('80', '150,00');

INSERT INTO VENDA(idVendedor, nomeVendedor, dataVenda, valor, id) VALUES('1', 'Vendedor1', '2019-05-05 18:00:00', '23,50', '10');
INSERT INTO VENDA(idVendedor, nomeVendedor, dataVenda, valor, id) VALUES('2', 'Vendedor2', '2019-05-05 19:00:00', '40,00' '20');
INSERT INTO VENDA(idVendedor, nomeVendedor, dataVenda, valor, id) VALUES('3', 'Vendedor3', '2019-05-05 20:00:00', '100,00', '40');