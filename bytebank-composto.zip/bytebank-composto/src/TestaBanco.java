
public class TestaBanco {
	public static void main(String[] args) {
		Cliente ze = new Cliente();
		ze.nome = "Jose Sanches Malassise";
		ze.cpf = "097.560.429-58";
		ze.profissao = "Programador";
		
		Conta conta = new Conta();
		conta.deposita(100);
		
		conta.titular = ze;
		System.out.println(conta.titular.nome);
	}
}
