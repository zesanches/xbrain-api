package br.com.alura.loja;

public class Produto {
	
}
